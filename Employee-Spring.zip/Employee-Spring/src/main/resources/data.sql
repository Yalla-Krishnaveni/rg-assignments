-- Insert sample data into Employee table
INSERT INTO Employee (id, name, department) VALUES (1, 'Krishnaveni', 'SRE');
INSERT INTO Employee (id, name, department) VALUES (2, 'Sreya', 'Risk');
